import flet
from flet import *
import grabcut_scan 

ex_statement = False
ScanStatus = 'Please import file'

class MainContainer(UserControl):
    def __init__(self):
        super().__init__()
    
    def build(selff):
        return Container(
            width=380,
            height=60,
            content=Column(
                spacing=5,
                horizontal_alignment=CrossAxisAlignment.CENTER,
                controls=[
                    Text(
                        "God I want this to be end ASAP",
                        size=10,
                        weight="w400",
                        color="white54"
                    ),
                    Text(
                        "DocScanner",
                        size=46,
                        weight="bold",
                        color="white"
                    ),
                ]
            )
        )

class StatusText(UserControl):
    def __init__(self):
        super().__init__()
    
    global StatusText 
    
    def build(self):
        return Container(
            width=380,
            height=50,
            content=Column(
                spacing=10,
                horizontal_alignment=CrossAxisAlignment.CENTER,
                controls=[
                    Text(
                        f"{ScanStatus}",
                        size=24,
                        weight="w80",
                        color="white"
                    ),
                ]
            )
        )

class DocScanner(UserControl):
    def __init__(self):
        super().__init__()
        
    def button_clicked(self, e):
        global ScanStatus, ex_statement
        data = e.control.data
        
        if data in ("import"):
            if ex_statement == False:
                self.result.value = 'Scanning images...'
                self.update()  
                ex_statement = grabcut_scan.im_image(ex_statement) 
                self.result.value = 'Scanning completed' 
                self.update()  
                return ex_statement
        
        elif data in("export"):
            if ex_statement == True:
                ex_statement = grabcut_scan.ex_image(ex_statement)
                self.result.value = 'Export completed' 
                self.update()  
            return ex_statement
        
    def reset(self):
        self.result = 'Please import image'
        
    def build(self):
        self.result = Text( 
                            value = 'Please import image', 
                            size=24,
                            weight="w80",
                            color="white"
                        )
        return Column(
            controls=[
                Divider(height=20, color="transparent"),
                Row(
                    controls=[
                        ElevatedButton(
                            text="Import",
                            width=340,
                            height=65,
                            bgcolor='#ECBDC4',
                            color="#ffffff",
                            data="import",
                            on_click=self.button_clicked
                        )
                    ]
                ),
                Divider(height=60, color="transparent"),
                Row(
                    
                    controls=[
                        ElevatedButton(
                            text="Export",
                            width=340,
                            height=65,
                            bgcolor='#ECBDC4',
                            color="#ffffff",
                            data="export",
                            on_click=self.button_clicked
                        )
                    ]
                ),
                Divider(height=120, color="transparent"),
                Container(
                    width=380,
                    height=50,
                    content=Column(
                        spacing=10,
                        horizontal_alignment=CrossAxisAlignment.CENTER,
                        controls=[self.result]
                    )
                )     
            ]
        )

def main(page: Page):
    
    page.title = "DocScanner V.1.0"
    
    page.vertical_alignment = MainAxisAlignment.CENTER 
    page.horizontal_alignment = MainAxisAlignment.CENTER
    
    WIDTH=380
    HEIGHT=800
    
    main_container = Container(
        width=WIDTH,
        height=HEIGHT,
        bgcolor='#EFCFD4',
        border_radius=40,
        padding=20,
        content=Column(
            
            controls=[
                Divider(height=40, color="transparent"),
                MainContainer(),
                Divider(height=20, color="transparent"),
                Divider(height=60, color="white31"),
                Divider(height=10, color="transparent"),
                DocScanner()
                # ImportButton(),
                # Divider(height=60, color="transparent"),
                # ExportButton(),
                # Divider(height=160, color="transparent"),
                # StatusText(),
            ]
              
        )
    )
    
    page.add(main_container)
    page.update()
    pass

if __name__ == "__main__":
    flet.app(target=main, assets_dir="assets")
